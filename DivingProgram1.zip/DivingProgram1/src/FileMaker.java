import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class FileMaker {
    // class to create a file from the DiveProfile Class
    // because i cant be bothered doing it all there now im making this specialized class for it

    // dive date (3 variables)
    // dive title (string variable)
    // dive time (3 variables)
    // dive location (string variable)
    // dive depth (int variable)
    // dive duration (int variable)

    public FileMaker(
            String title,
            String location,
            int depth,
            int duration,

            // Time
            String ampm,
            int hour,
            int minute,

            // Date
            int day,
            String month,
            int year

    ) throws ParseException {

        // convert 'time' variables into a singular value with a specific variable type

        // convert 'date' into the date format

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MMM.yyyy");
        SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm aa");

        Date date = new Date();
        Date time = new Date();

        String dayString = String.valueOf(day);
        String yearString = String.valueOf(year);

        String hourString = String.valueOf(hour);
        String minuteString = String.valueOf(minute);

        if(minuteString.length() == 1) {
            minuteString = "0" + minuteString;
        }


        String dateToBeConverted = dayString + '.' + month + '.' + yearString;
        String timeToBeConverted = hourString + ':' + minuteString + ' ' + ampm;
        date = dateFormat.parse(dateToBeConverted);                                     // TODO date formats arent working :(((
        time = timeFormat.parse(timeToBeConverted);



        // Print out checks
        System.out.println(date);
        System.out.println(time);
        System.out.println(title);
        System.out.println(location);
        System.out.println(depth);
        System.out.println(duration);

    }

}
