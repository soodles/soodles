public class Main {

    public static void main(String[] args) {
        DiveProfile dp = new DiveProfile();
    }

}
