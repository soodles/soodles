import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;

public class DiveProfile extends JFrame {
    private JPanel DivePanel;

    String[] monthArray                 = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    int[] yearArray                     = {2022, 2023, 2024, 2025, 2026, 2027, 2028, 2029, 2030};
    String[] ampmArray                  = {"AM", "PM"};

    private JTextField diveTitleField;
    private JTextField diveLocationField;
    private JSpinner depthInput;
    private JSpinner depthDuration;

    // DATE
    private JComboBox dateDayBox;
    private JComboBox dateMonthBox;
    private JComboBox dateYearBox;

    // TIME
    private JComboBox hourSpinner;
    private JComboBox minuteSpinner;
    private JComboBox ampmSpinner;


    private JLabel durationErrorLabel;
    private JLabel depthErrorLabel;

    private JButton fileCreateButton;
    private JLabel errorLabel;


    public DiveProfile() {
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setTitle("Dive Profile Creator");
        setVisible(true);
        setContentPane(DivePanel);
        setSize(600, 400);


        for (int x = 0; x < 31; x++) {
            dateDayBox.addItem(x+1);
        }
        for (int x = 0; x < monthArray.length; x++) {
            dateMonthBox.addItem(monthArray[x]);
        }
        for (int x = 0; x < yearArray.length; x++) {
            dateYearBox.addItem(yearArray[x]);
        }

        for (int x = 0; x < 12; x++) {
            hourSpinner.addItem(x + 1);
        }
        for (int x = 0; x < 60; x++) {
            minuteSpinner.addItem(x);
        }

        for (int x = 0; x < ampmArray.length; x++) {
            ampmSpinner.addItem(ampmArray[x]);
        }

        // convert the time thingies into a time value

        fileCreateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                errorLabel.setText("");
                // Calls upon the filemaker class to make a file.
                // as of writing it is only configured to print the values to console, file making functionality is not complete yet.

                int depth       = (int) depthInput.getValue();
                int duration    = (int) depthDuration.getValue();

                // run a check to see that the dive depth and duration are within the limits then run file maker

                if(DepthDurationValidifier(depth, depthErrorLabel, duration, durationErrorLabel)) {


                    errorLabel.setVisible(false);

                    String title    = diveTitleField.getText();
                    String location = diveLocationField.getText();


                    // Time
                    int hour        = (int) hourSpinner.getSelectedItem();
                    int minute      = (int) minuteSpinner.getSelectedItem();
                    String ampm     = (String) ampmSpinner.getSelectedItem();

                    // Date
                    int day         = (int) dateDayBox.getSelectedItem();
                    String month    = (String) dateMonthBox.getSelectedItem();
                    int year        = (int) dateYearBox.getSelectedItem();

                    try {
                        new FileMaker(title, location, depth, duration, ampm, hour, minute, day, month, year);
                    } catch (ParseException ex) {
                        throw new RuntimeException(ex);
                    }
                } else {
                    // Throw an error statement
                    errorLabel.setVisible(true);
                }

            }
        });



    }

    private boolean DepthDurationValidifier(int depth, JLabel depthErrorLabel, int duration, JLabel durationErrorLabel) {

        // go through each variable, validify then if not valid call a different method

        boolean allCorrect = true;

        if(depth == 0 || depth > 20) {          // DEPTH MUST BE WITHIN 1 AND 20
            allCorrect = false;
            Error(depthErrorLabel);
        } else {
            Valid(depthErrorLabel);
        }

        if(depth == 0) {
            errorLabel.setText(errorLabel.getText() + "Depth must be greater than 0m. ");
        }

        if(depth > 20) {
            errorLabel.setText(errorLabel.getText() + "Depth must be less than 20m. ");
        }

        if(duration == 0 || duration >120) {    // DURATION MUST BE WITHIN 1 AND 120
            allCorrect = false;
            Error(durationErrorLabel);
        } else {
            Valid(durationErrorLabel);
        }

        if(duration == 0) {
            errorLabel.setText(errorLabel.getText() + "Duration must be greater than 0 min. ");
        }

        if(duration > 120) {
            errorLabel.setText(errorLabel.getText() + "Duration must be less than 120 min. ");
        }

        return allCorrect;
    }

    private void Error(JLabel label) {
        label.setVisible(true);
    }

    private void Valid(JLabel label) {
        label.setVisible(false);
    }


}
