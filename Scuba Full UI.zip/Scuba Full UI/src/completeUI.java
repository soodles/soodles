import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class completeUI extends JFrame {
    private JPanel bigDaddy; 

    private JPanel GoogleMaps; // TODO google maps api... fuck

    private JPanel RightHalf;

    private JButton Settings;
    private JTextField SearchBar;
    private JComboBox sortComboBox;
    private JButton switchCards; // SWITCHES BETWEEN CREATE A NEW DIVE PROFILE AND SCROLLBAR, IT HAS TO CHANGE NAME DEPENDING ON THE SWITCH AS WELL.

    private JPanel Cards;

    private JScrollPane ScrollPanel;
    private JScrollBar scrollBar1;

    private JPanel DiveProfileCreator;
    private JTextField diveTitle;

    // DATE INPUTS
    private JComboBox day;
    private JComboBox month;
    private JComboBox year;

    // TIME INPUTS
    private JComboBox hour;
    private JComboBox minute;
    private JComboBox AMPM;

    private JTextField diveLocation;
    private JSpinner diveDepth;
    private JSpinner diveDuration;

    private JLabel diveTitleError;
    private JLabel diveDateError;
    private JLabel timeofDiveError;
    private JLabel diveLocationError;
    private JLabel diveDepthError;
    private JLabel diveDurationError;

    private JButton createNewDiveProfileButton;




    private JLabel errorStatement;


    //hhhhhhhhhhhh
    // there is so many variables im going to have to organize if i even want a chance for this to work
    // haha


    public completeUI() {
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setTitle("Scuba Planning Software");
        setVisible(true);
        setContentPane(bigDaddy);
        setSize(800,600);

        // TODO
        // Create a new class that create new dive profile will save the files to whichever place is selected in the settings tab
        createNewDiveProfileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
    }

}
